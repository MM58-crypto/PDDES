from django.urls import path

from inference_engine import views


app_name = 'inference_engine'

#urlpatterns = [
#    path('test/', views.Test_View.as_view(), name="test"),
#]